// https://www.shadertoy.com/view/4dSGW1
const VIS_SAMPLES: i32 = 1;

// --- Texture Placeholder Functions ---

fn get_channel_0(uv: vec2<f32>) -> vec4<f32> {
    // Replacement for iChannel0 (Noise/Heightmap)
    let h = 0.2 * fract(sin(dot(uv, vec2<f32>(12.9898, 78.233))) * 43758.5453);
    return vec4<f32>(h);
}

fn get_channel_1(uv: vec2<f32>) -> vec4<f32> {
    // Replacement for iChannel1 (Blue Noise / Random)
    return vec4<f32>(
        fract(sin(dot(uv, vec2<f32>(12.9, 78.2))) * 43758.5),
        fract(sin(dot(uv, vec2<f32>(23.3, 51.1))) * 12345.6),
        fract(sin(dot(uv, vec2<f32>(34.5, 91.2))) * 78910.1),
        fract(sin(dot(uv, vec2<f32>(45.6, 12.3))) * 54321.0)
    );
}

fn get_channel_2(uv: vec2<f32>) -> vec4<f32> {
    // Replacement for iChannel2
    return vec4<f32>(0.5 + 0.5 * sin(uv.x * 10.0));
}

fn get_channel_3(uv: vec2<f32>) -> vec4<f32> {
    // Replacement for iChannel3 (Cylinder Texture)
    return vec4<f32>(0.5 + 0.45 * sin(uv.y * 20.0 + vec3<f32>(0.0, 1.0, 2.0)), 1.0);
}

// --- Math Helpers ---

fn hash1(n: f32) -> f32 { return fract(43758.5453123 * sin(n)); }
fn hash1_v2(n: vec2<f32>) -> f32 { return fract(43758.5453123 * sin(dot(n, vec2<f32>(1.0, 113.0)))); }
fn hash2(n: f32) -> vec2<f32> { return fract(43758.5453123 * sin(vec2<f32>(n, n + 1.0))); }

var<private> gAnimTime: f32;

fn map(p: vec2<f32>) -> f32 {
    var f = get_channel_0(p / 256.0).x; // Assuming a 256x256 resolution for height
    f *= sqrt(get_channel_2((0.03 * p + 2.0 * gAnimTime) / 256.0).x);
    return 22.0 * f;
}

fn calcNormal(pos: vec3<f32>, ic: f32) -> vec3<f32> {
    return mix(normalize(vec3<f32>(pos.x, 0.0, pos.z)), vec3<f32>(0.0, 1.0, 0.0), ic);
}

fn raycast(ro: vec3<f32>, rd: vec3<f32>) -> vec4<f32> {
    var pos = floor(ro.xz);
    let ri = 1.0 / rd.xz;
    let rs = sign(rd.xz);
    let ris = ri * rs;
    var dis = (pos - ro.xz + 0.5 + rs * 0.5) * ri;
    
    var res = vec4<f32>(-1.0, 0.0, 0.0, 0.0);

    for (var i: i32 = 0; i < 200; i++) {
        let ma = map(pos);
        let ce = vec3<f32>(pos.x + 0.5, 0.0, pos.y + 0.5);
        let rc = ro - ce;
        let a = dot(rd.xz, rd.xz);
        let b = dot(rc.xz, rd.xz);
        let c = dot(rc.xz, rc.xz) - 0.249;
        let h = b * b - a * c;

        if (h >= 0.0) {
            var s = (-b - sqrt(h)) / a;
            if (s > 0.0 && (ro.y + s * rd.y) < ma) {
                res = vec4<f32>(s, 0.0, pos);
                break;
            }
            s = (ma - ro.y) / rd.y;
            if (s > 0.0 && (s * s * a + 2.0 * s * b + c) < 0.0) {
                res = vec4<f32>(s, 1.0, pos);
                break;
            }
        }

        let mm = step(dis.xy, dis.yx);
        dis += mm * ris;
        pos += mm * rs;
    }
    return res;
}

fn castShadowRay(ro: vec3<f32>, rd: vec3<f32>) -> f32 {
    var pos = floor(ro.xz);
    let ri = 1.0 / rd.xz;
    let rs = sign(rd.xz);
    let ris = ri * rs;
    var dis = (pos - ro.xz + 0.5 + rs * 0.5) * ri;
    var res: f32 = 1.0;
    
    let mm1 = step(dis.xy, dis.yx);
    dis += mm1 * ris;
    pos += mm1 * rs;
    
    for (var i: i32 = 0; i < 16; i++) {
        let ma = map(pos);
        let ce = vec3<f32>(pos.x + 0.5, 0.0, pos.y + 0.5);
        let rc = ro - ce;
        let a = dot(rd.xz, rd.xz);
        let b = dot(rc.xz, rd.xz);
        let c = dot(rc.xz, rc.xz) - 0.249;
        let h = b * b - a * c;
        if (h >= 0.0) {
            let t = (-b - sqrt(h)) / a;
            if (t > 0.0 && (ro.y + t * rd.y) < ma) {
                res = 0.0;
                break;
            }
        }
        let mm = step(dis.xy, dis.yx);
        dis += mm * ris;
        pos += mm * rs;
    }
    return res;
}

fn cameraPath(t: f32) -> vec3<f32> {
    var p = 200.0 * sin(0.01 * t * vec2<f32>(1.2, 1.0) + vec2<f32>(0.1, 0.9));
    p += 100.0 * sin(0.02 * t * vec2<f32>(1.1, 1.3) + vec2<f32>(1.0, 4.5));
    var y = 15.0 + 4.0 * sin(0.05 * t);
    
    var h = map(p + vec2<f32>(-1.0, 0.0));
    h += map(p + vec2<f32>(1.0, 0.0));
    h += map(p + vec2<f32>(0.0, 1.0));
    h += map(p + vec2<f32>(0.0, -1.0));
    h = h / 4.0 + 5.0;
    return vec3<f32>(p.x, max(y, h), p.y);
}

fn texcyl(p: vec3<f32>, n: vec3<f32>) -> vec4<f32> {
    let x = get_channel_3(vec2<f32>(p.y, 0.5 + 0.5 * atan2(n.x, n.z) / 3.14159));
    let y = get_channel_3(p.xz);
    return mix(x, y, abs(n.y));
}

const lig = vec3<f32>(-0.7, 0.25, 0.6); // Needs to be normalized in use or here

fn render(ro: vec3<f32>, rd: vec3<f32>) -> vec3<f32> {
    let l_norm = normalize(lig);
    let sun = clamp(dot(rd, l_norm), 0.0, 1.0);
    let bgcol = vec3<f32>(0.9, 1.0, 1.0) + 0.3 * pow(sun, 4.0);
    var col = bgcol;
    
    let res = raycast(ro, rd);
    let t = res.x;
    if (t > 0.0) {
        let vos = res.zw;
        let pos = ro + rd * t;
        let id = hash1_v2(vos);
        let nor = calcNormal(fract(pos) - 0.5, res.y);
        let h = map(vos);

        var mate = 0.55 + 0.45 * sin(2.0 * id + 1.8 + vec3<f32>(0.0, 0.5, 1.0));
        let uvw = pos - vec3<f32>(0.0, h, 0.0);
        let tex = texcyl(0.2 * uvw + 13.1 * hash1(id), nor).xyz;
        mate *= 0.2 + 4.0 * tex * tex;
        mate *= 0.02 + 0.98 * smoothstep(0.1, 0.11, hash1(id));

        var occ = nor.y * 0.75;
        occ += 0.5 * clamp(nor.x, 0.0, 1.0) * smoothstep(-0.5, 0.5, pos.y - map(vos + vec2<f32>(1.0, 0.0)));
        occ += 0.5 * clamp(-nor.x, 0.0, 1.0) * smoothstep(-0.5, 0.5, pos.y - map(vos + vec2<f32>(-1.0, 0.0)));
        occ += 0.5 * clamp(nor.z, 0.0, 1.0) * smoothstep(-0.5, 0.5, pos.y - map(vos + vec2<f32>(0.0, 1.0)));
        occ += 0.5 * clamp(-nor.z, 0.0, 1.0) * smoothstep(-0.5, 0.5, pos.y - map(vos + vec2<f32>(0.0, -1.0)));
        occ = 0.2 + 0.8 * occ;
        occ *= pow(clamp((0.1 + pos.y) / (0.1 + map(floor(pos.xz))), 0.0, 1.0), 2.0);
        occ = occ * 0.5 + 0.5 * occ * occ;
        let rim = pow(clamp(1.0 + dot(rd, nor), 0.0, 1.0), 5.0);

        let bac = clamp(dot(nor, normalize(vec3<f32>(-l_norm.x, 0.0, -l_norm.z))), 0.0, 1.0) * clamp(1.0 - pos.y / 20.0, 0.0, 1.0);
        var dif = dot(nor, l_norm);
        if (dif > 0.0) { dif *= castShadowRay(pos, l_norm); }
        dif = max(dif, 0.0);
        let spe = pow(clamp(dot(l_norm, reflect(rd, nor)), 0.0, 1.0), 3.0);

        var lin = 3.00 * vec3<f32>(1.0) * dif;
        lin += 0.80 * vec3<f32>(0.4, 1.0, 1.7) * occ;
        lin += 0.30 * vec3<f32>(0.8, 0.5, 0.3) * bac * occ;

        col = mate * lin + tex.x * 1.5 * (0.3 + 0.7 * rim) * spe * dif;
        let ff = 1.0 - smoothstep(0.0, 1.0, pow(t / 160.0, 1.8));
        col = mix(bgcol, col, ff);
    }
    col += 0.2 * pow(sun, 8.0) * vec3<f32>(1.0, 0.7, 0.2);
    return col;
}

fn main(p: vec2f, pixel: vec2f, options: Options) -> vec4<f32> {
    let mo = options.mouse.xy / vec2f(options.resolution);
    gAnimTime = options.time;
    let fragCoord = vec2f(pixel.x, f32(options.resolution.y) - pixel.y);
    
    var tot = vec3<f32>(0.0);
    
    for (var a: i32 = 0; a < VIS_SAMPLES; a++) {
        let rr = get_channel_1((fragCoord.xy + floor(256.0 * hash2(f32(a)))) / 256.0);
        var p = -1.0 + 2.0 * (fragCoord.xy + rr.xz) / vec2f(options.resolution);
        p.x *= f32(options.resolution.x) / f32(options.resolution.y);
        
        let time = 4.0 * (options.time + (0.4 / 24.0) * rr.w) + 50.0 * mo.x;

        let ro = cameraPath(time);
        let ta_orig = cameraPath(time + 5.0);
        let ta = vec3<f32>(ta_orig.x, ro.y - 5.5, ta_orig.z);
        let cr = 0.2 * cos(0.1 * time * 0.5);

        let ww = normalize(ta - ro);
        let uu = normalize(cross(vec3<f32>(sin(cr), cos(cr), 0.0), ww));
        let vv = normalize(cross(ww, uu));
        
        let r2 = p.x * p.x * 0.32 + p.y * p.y;
        let p_distorted = p * (7.0 - sqrt(37.5 - 11.5 * r2)) / (r2 + 1.0);
        var rd = normalize(p_distorted.x * uu + p_distorted.y * vv + 2.5 * ww);

        // DOF
        let fp = ro + rd * 17.0;
        let ro_dof = ro + (uu * (-1.0 + 2.0 * rr.y) + vv * (-1.0 + 2.0 * rr.w)) * 0.035;
        rd = normalize(fp - ro_dof);

        tot += render(ro_dof, rd);
    }
    tot /= f32(VIS_SAMPLES);

    tot = tot * 1.2 / (1.0 + tot);
    tot = pow(saturate(tot), vec3<f32>(0.45));
    tot = tot * tot * (3.0 - 2.0 * tot);
    
    let q = fragCoord.xy / vec2f(options.resolution);
    tot *= 0.5 + 0.5 * pow(16.0 * q.x * q.y * (1.0 - q.x) * (1.0 - q.y), 0.1);
    
    return vec4<f32>(tot, 1.0);
}