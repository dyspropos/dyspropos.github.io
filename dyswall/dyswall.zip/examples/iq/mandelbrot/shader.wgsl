// Copyright Inigo Quilez, 2013 - https://iquilezles.org/
// I am the sole copyright owner of this Work.
// You cannot host, display, distribute or share this Work neither
// as it is or altered, here on Shadertoy or anywhere else, in any
// form including physical and digital. You cannot use this Work in any
// commercial or non-commercial product, website or project. You cannot
// sell this Work and you cannot mint an NFTs of it or train a neural
// network with it without permission. I share this Work for educational
// purposes, and you can link to it, through an URL, proper attribution
// and unmodified screenshot, as part of your educational material. If
// these conditions are too restrictive please contact me and we'll
// definitely work it out.

// This shader computes the distance to the Mandelbrot Set for everypixel, and colorizes
// it accordingly.
// 
// Z -> Z²+c, Z0 = 0. 
// therefore Z' -> 2·Z·Z' + 1
//
// The Hubbard-Douady potential G(c) is G(c) = log Z/2^n
// G'(c) = Z'/Z/2^n
//
// So the distance is |G(c)|/|G'(c)| = |Z|·log|Z|/|Z'|
//
// More info:
// https://iquilezles.org/articles/distancefractals

fn hot_gradient(t: f32) -> vec3<f32> {
    // Clamp input to ensure it stays within 0.0 - 1.0 range
    let x = saturate(t);

    var col: vec3<f32>;
    
    // Red channel: Starts immediately, hits full brightness at 1/3
    col.r = saturate(x * 3.0);
    
    // Green channel: Starts at 1/3, hits full brightness at 2/3 (making yellow)
    col.g = saturate((x - 0.333) * 3.0);
    
    // Blue channel: Starts at 2/3, hits full brightness at 1.0 (making white)
    col.b = saturate((x - 0.666) * 3.0);

    return col;
}

fn distanceToMandelbrot(c: vec2<f32>) -> f32 {
    var z = vec2<f32>(0.0);
    var dz = vec2<f32>(0.0);
    var m2: f32 = 0.0;
    var di: f32 = 1.0;

    for (var i: i32 = 0; i < 800; i++) {
        if (m2 > 1024.0) {
            di = 0.0;
            break;
        }

        // Complex derivative: Z' -> 2·Z·Z' + 1
        // (x+iy)' = 2 * (z.x + i*z.y) * (dz.x + i*dz.y) + 1
        dz = 2.0 * vec2<f32>(z.x * dz.x - z.y * dz.y, z.x * dz.y + z.y * dz.x) + vec2<f32>(1.0, 0.0);

        // Complex square: Z -> Z² + c
        z = vec2<f32>(z.x * z.x - z.y * z.y, 2.0 * z.x * z.y) + c;

        m2 = dot(z, z);
    }

    // distance calculation: d(c) = |Z|·log|Z|/|Z'|
    // We use 0.5 * sqrt(m2/dot(dz,dz)) * log(m2) 
    // Note: log(dot(z,z)) is equivalent to 2.0 * log(length(z))
    let d = 0.5 * sqrt(dot(z, z) / dot(dz, dz)) * log(dot(z, z));
    
    return d;
}

fn main(uv: vec2f, fragCoord: vec2f, options: Options) -> vec4<f32> {
    // Standardize UV coordinates to [-1, 1] on Y axis
    let p = (2.0 * fragCoord.xy - vec2f(options.resolution)) / f32(options.resolution.y);

    // Animation logic
    let tz = 0.5 - 0.5 * cos(0.225 * options.time);
    let zoo = pow(0.5, 13.0 * tz);
    let c = vec2<f32>(-0.05, 0.6805) + p * zoo;

    // Distance to Mandelbrot
    var d = distanceToMandelbrot(c);

    // Soft coloring based on distance
    // We normalize the distance by the zoom factor to keep line thickness consistent
    d = clamp(pow(4.0 * d / zoo, 0.2), 0.0, 1.0);

    let col = hot_gradient(1.0 - d);

    return vec4<f32>(col, 1.0);
}