/// https://www.shadertoy.com/view/4sX3Rn
// The MIT License
// https://www.youtube.com/c/InigoQuilez
// https://iquilezles.org/
// Copyright © 2013 Inigo Quilez
// Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

// https://iquilezles.org/articles/menger


const AA: i32 = 1;

fn maxcomp(p: vec3<f32>) -> f32 {
    return max(p.x, max(p.y, p.z));
}

fn sdBox(p: vec3<f32>, b: vec3<f32>) -> f32 {
    let di = abs(p) - b;
    return min(maxcomp(di), length(max(di, vec3<f32>(0.0))));
}

fn iBox(ro: vec3<f32>, rd: vec3<f32>, rad: vec3<f32>) -> vec2<f32> {
    let m = 1.0 / rd;
    let n = m * ro;
    let k = abs(m) * rad;
    let t1 = -n - k;
    let t2 = -n + k;
    return vec2<f32>(
        max(max(t1.x, t1.y), t1.z),
        min(min(t2.x, t2.y), t2.z)
    );
}

const ma = mat3x3<f32>(
    0.6, 0.0, 0.8,
    0.0, 1.0, 0.0,
    -0.8, 0.0, 0.6
);

fn map(p_in: vec3<f32>) -> vec4<f32> {
    var p = p_in;
    var d = sdBox(p, vec3<f32>(1.0));
    var res = vec4<f32>(d, 1.0, 0.0, 0.0);

    let ani = smoothstep(-0.2, 0.2, -cos(0.5 * options.time));
    let off = 1.5 * sin(0.01 * options.time);
    
    var s: f32 = 1.0;
    for (var m: i32 = 0; m < 4; m++) {
        p = mix(p, ma * (p + off), ani);
       
        let a = ((p * s) % 2.0 + 2.0) % 2.0 - 1.0; // Proper GLSL mod equivalent
        s *= 3.0;
        let r = abs(1.0 - 3.0 * abs(a));
        let da = max(r.x, r.y);
        let db = max(r.y, r.z);
        let dc = max(r.z, r.x);
        let c = (min(da, min(db, dc)) - 1.0) / s;

        if (c > d) {
            d = c;
            res = vec4<f32>(d, min(res.y, 0.2 * da * db * dc), (1.0 + f32(m)) / 4.0, 0.0);
        }
    }
    return res;
}

fn intersect(ro: vec3<f32>, rd: vec3<f32>) -> vec4<f32> {
    let bb = iBox(ro, rd, vec3<f32>(1.05));
    if (bb.y < bb.x) { return vec4<f32>(-1.0); }
    
    var t = bb.x;
    let tmax = bb.y;
    var res = vec4<f32>(-1.0);
    
    for (var i: i32 = 0; i < 64; i++) {
        let h = map(ro + rd * t);
        if (h.x < 0.002 || t > tmax) { break; }
        res = vec4<f32>(t, h.yzw);
        t += h.x;
    }
    if (t > tmax) { res = vec4<f32>(-1.0); }
    return res;
}

fn softshadow(ro: vec3<f32>, rd: vec3<f32>, mint: f32, k: f32) -> f32 {
    let bb = iBox(ro, rd, vec3<f32>(1.05));
    let tmax = bb.y;
    
    var res: f32 = 1.0;
    var t = mint;
    for (var i: i32 = 0; i < 64; i++) {
        let h = map(ro + rd * t).x;
        res = min(res, k * h / t);
        if (res < 0.001) { break; }
        t += clamp(h, 0.005, 0.1);
        if (t > tmax) { break; }
    }
    return clamp(res, 0.0, 1.0);
}

fn calcNormal(pos: vec3<f32>) -> vec3<f32> {
    let eps = vec2<f32>(0.001, 0.0);
    return normalize(vec3<f32>(
        map(pos + eps.xyy).x - map(pos - eps.xyy).x,
        map(pos + eps.yxy).x - map(pos - eps.yxy).x,
        map(pos + eps.yyx).x - map(pos - eps.yyx).x
    ));
}

fn render(ro: vec3<f32>, rd: vec3<f32>) -> vec3<f32> {
    var col = mix(vec3<f32>(0.3, 0.2, 0.1) * 0.5, vec3<f32>(0.7, 0.9, 1.0), 0.5 + 0.5 * rd.y);
    
    let tmat = intersect(ro, rd);
    if (tmat.x > 0.0) {
        let pos = ro + tmat.x * rd;
        let nor = calcNormal(pos);
        let matcol = 0.5 + 0.5 * cos(vec3<f32>(0.0, 1.0, 2.0) + 2.0 * tmat.z);
        let occ = tmat.y;

        let light = normalize(vec3<f32>(1.0, 0.9, 0.3));
        let dif = max(dot(nor, light), 0.0);
        var sha: f32 = 1.0;
        if (dif > 0.0) { sha = softshadow(pos, light, 0.01, 64.0); }
        
        let hal = normalize(light - rd);
        let spe = dif * sha * pow(clamp(dot(hal, nor), 0.0, 1.0), 16.0) * (0.04 + 0.96 * pow(clamp(1.0 - dot(hal, light), 0.0, 1.0), 5.0));
        
        let sky = 0.5 + 0.5 * nor.y;
        let bac = max(0.4 + 0.6 * dot(nor, vec3<f32>(-light.x, light.y, -light.z)), 0.0);

        var lin = vec3<f32>(0.0);
        lin += 1.00 * dif * vec3<f32>(1.10, 0.85, 0.60) * sha;
        lin += 0.50 * sky * vec3<f32>(0.10, 0.20, 0.40) * occ;
        lin += 0.10 * bac * vec3<f32>(1.00, 1.00, 1.00) * (0.5 + 0.5 * occ);
        lin += 0.25 * occ * vec3<f32>(0.15, 0.17, 0.20);     
        col = matcol * lin + spe * 128.0;
    }

    col = 1.5 * col / (1.0 + col);
    return sqrt(col);
}

fn main(p: vec2f, fragCoord: vec2f, options: Options) -> vec4<f32> {
    let ro = 1.1 * vec3<f32>(
        2.5 * sin(0.25 * options.time),
        1.0 + 1.0 * cos(options.time * 0.13),
        2.5 * cos(0.25 * options.time)
    );

    var col = vec3<f32>(0.0);
    
    // Anti-aliasing loop
    for (var m: i32 = 0; m < AA; m++) {
        for (var n: i32 = 0; n < AA; n++) {
            let o = vec2<f32>(f32(m), f32(n)) / f32(AA) - 0.5;
            let p = (2.0 * (fragCoord.xy + o) - vec2f(options.resolution)) / f32(options.resolution.y);

            let ww = normalize(vec3<f32>(0.0) - ro);
            let uu = normalize(cross(vec3<f32>(0.0, 1.0, 0.0), ww));
            let vv = normalize(cross(ww, uu));
            let rd = normalize(p.x * uu + p.y * vv + 2.5 * ww);

            col += render(ro, rd);
        }
    }
    col /= f32(AA * AA);
    
    return vec4<f32>(col, 1.0);
}