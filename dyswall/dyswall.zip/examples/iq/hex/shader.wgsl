// --- Texture Placeholder ---
fn get_noise_tex(uv: vec2f) -> vec2f {
    // Standard 2D Hash
    let h = fract(sin(dot(0.0001 * uv ,vec2f(12.9898, 78.233))) * 43758.5453);
    let h2 = fract(sin(dot(0.0001 * uv ,vec2f(37.1, 113.7))) * 43758.5453);
    return vec2f(h, h2);
}

// --- Hexagonal Grid Logic ---
fn hexagon(p: vec2f) -> vec4f {
    let q = vec2f(p.x * 2.0 * 0.5773503, p.y + p.x * 0.5773503);
    
    let pi = floor(q);
    let pf = fract(q);

    let v = (pi.x + pi.y) % 3.0;

    let ca = step(1.0, v);
    let cb = step(2.0, v);
    let ma = step(pf.xy, pf.yx);
    
    // distance to borders
    let e = dot(ma, 1.0 - pf.yx + ca * (pf.x + pf.y - 1.0) + cb * (pf.yx - 2.0 * pf.xy));

    // distance to center    
    let p_cntr = vec2f(q.x + floor(0.5 + p.y / 1.5), 4.0 * p.y / 3.0) * 0.5 + 0.5;
    let f_dist = length((fract(p_cntr) - 0.5) * vec2f(1.0, sqrt(3.0) / 2.0));        
    
    return vec4f(pi + ca - cb * ma, e, f_dist);
}

fn hash1(p: vec2f) -> f32 { 
    let n = dot(p, vec2f(127.1, 311.7)); 
    return fract(sin(n) * 43758.5453); 
}

fn noise(x: vec3f) -> f32 {
    let p = floor(x);
    var f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    let uv = (p.xy + vec2f(37.0, 17.0) * p.z) + f.xy;
    let rg = get_noise_tex((uv + 0.5) / 256.0);
    return mix(rg.x, rg.y, f.z);
}

const AA: i32 = 2;

fn main(p_in: vec2f, pixel: vec2f, options: Options) -> vec4f {
    let iResolution = vec2f(options.resolution);
    var tot = vec3f(0.0);
    let time = 0.1 * options.time + 20.0;
    
    for (var mm: i32 = 0; mm < AA; mm++) {
        for (var nn: i32 = 0; nn < AA; nn++) {
            let off = vec2f(f32(mm), f32(nn)) / f32(AA);
            
            // Note: 'pixel' is already Y-inverted per requirements
            let uv = (pixel + off) / iResolution;
            var pos = (-iResolution + 2.0 * (pixel + off)) / iResolution.y;

            // Distort
            pos *= 1.2 + 0.15 * length(pos);

            // Layer 1: Gray Hexagons
            var h = hexagon(8.0 * pos + 0.5 * time);
            var n = noise(vec3f(0.3 * h.xy + time * 0.1, time));
            var col = 0.15 + 0.15 * hash1(h.xy + 1.2) * vec3f(1.0);
            col *= smoothstep(0.10, 0.11, h.z);
            col *= smoothstep(0.10, 0.11, h.w);
            col *= 1.0 + 0.15 * sin(40.0 * h.z);
            col *= 0.75 + 0.5 * h.z * n;

            // Layer 2: Shadows
            h = hexagon(6.0 * (pos + 0.1 * vec2f(-1.3, 1.0)) + 0.6 * time);
            let shadow_n = noise(vec3f(0.3 * h.xy + time * 0.1, 0.5 * time));
            col *= 1.0 - 0.8 * smoothstep(0.45, 0.451, shadow_n);

            // Layer 3: Red Hexagons
            h = hexagon(6.0 * pos + 0.6 * time);
            n = noise(vec3f(0.3 * h.xy + time * 0.1, 0.5 * time));
            var colb = 0.9 + 0.8 * sin(hash1(h.xy) * 1.5 + 2.0 + vec3f(0.1, 1.3, 1.1));
            colb *= smoothstep(0.10, 0.11, h.z);
            colb *= 1.0 + 0.15 * sin(40.0 * h.z);

            col = mix(col, colb, smoothstep(0.45, 0.451, n));
            
            // Tone mapping
            col *= 2.5 / (2.0 + col);

            // Vignetting
            col *= pow(16.0 * uv.x * (1.0 - uv.x) * uv.y * (1.0 - uv.y), 0.1);

            tot += col;
        }
    }
    
    tot /= f32(AA * AA);
    return vec4f(tot, 1.0);
}