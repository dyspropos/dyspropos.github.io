// https://www.shadertoy.com/view/MsXGRf

// --- Placeholder for iChannel0 (Noise Texture) ---
fn get_noise_tex(uv: vec2<f32>) -> vec2<f32> {
    // Simulated 2D noise texture lookup
    // In a real app, this would be: return textureSampleLevel(t0, s0, uv, 0.0).yx;
    let i = floor(uv);
    let f = fract(uv);
    let n = i.x + i.y * 57.0;
    let res = fract(sin(vec2<f32>(n, n + 1.0)) * 43758.5453);
    return mix(vec2<f32>(res.x), vec2<f32>(res.y), f.x);
}

fn noise(x: vec3<f32>) -> f32 {
    let p = floor(x);
    var f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    
    // Low quality path (using texture interpolation logic)
    let uv = (p.xy + vec2<f32>(37.0, 17.0) * p.z) + f.xy;
    let rg = get_noise_tex((uv + 0.5) / 256.0);
    return mix(rg.x, rg.y, f.z);
}

fn map(p_in: vec3<f32>) -> vec4<f32> {
    let r = p_in;
    var p = p_in;
    p.y += 0.6;
    
    // Invert space
    p = -4.0 * p / dot(p, p);
    
    // Twist space
    let an = -1.0 * sin(0.1 * options.time + length(p.xz) + p.y);
    let co = cos(an);
    let si = sin(an);
    let rot = mat2x2<f32>(co, -si, si, co);
    p = vec3<f32>(rot * p.xz, p.y).xzy; // Reconstruct rotated xz
    
    // Distort
    let n_val = noise(p * 1.1);
    p.x += -1.0 + 2.0 * n_val;
    p.z += -1.0 + 2.0 * n_val;
    
    // Pattern (FBM)
    var f: f32 = 0.0;
    var q = p * 0.85 - vec3<f32>(0.0, 1.0, 0.0) * options.time * 0.12;
    
    f += 0.50000 * noise(q); q = q * 2.02 - vec3<f32>(0.0, 1.0, 0.0) * options.time * 0.12;
    f += 0.25000 * noise(q); q = q * 2.03 - vec3<f32>(0.0, 1.0, 0.0) * options.time * 0.12;
    f += 0.12500 * noise(q); q = q * 2.01 - vec3<f32>(0.0, 1.0, 0.0) * options.time * 0.12;
    f += 0.06250 * noise(q); q = q * 2.02 - vec3<f32>(0.0, 1.0, 0.0) * options.time * 0.12;
    f += 0.04000 * noise(q); q = q * 2.00 - vec3<f32>(0.0, 1.0, 0.0) * options.time * 0.12;
    
    let den = saturate((-r.y - 0.6 + 4.0 * f) * 1.2);
    
    var col = 1.2 * mix(vec3<f32>(1.0, 0.8, 0.6), 0.9 * vec3<f32>(0.3, 0.2, 0.35), den);
    col += 0.05 * sin(0.05 * q);
    
    // Texture-less patterns
    let s1 = sin(0.7 * q.x) * sin(0.7 * q.y) * sin(0.7 * q.z);
    col *= 1.0 - 0.8 * smoothstep(0.6, 1.0, s1) * vec3<f32>(0.6, 1.0, 0.8);
    
    let l1 = length((fract(q.xz * 0.12) - 0.5) / 0.5);
    col *= 1.0 + 1.0 * smoothstep(0.5, 1.0, 1.0 - l1) * vec3<f32>(1.0, 0.9, 0.8);
    
    col = mix(vec3<f32>(0.8, 0.32, 0.2), col, saturate((r.y + 0.1) / 1.5));
    
    return vec4<f32>(col, den);
}

fn main(p: vec2f, pixel: vec2f, options: Options) -> vec4<f32> {
    let fragCoord = vec2f(pixel.x, f32(options.resolution.y) - pixel.y);

    let q_uv = fragCoord.xy / vec2f(options.resolution);
    let p_ndc = (-1.0 + 2.0 * q_uv) * vec2<f32>(f32(options.resolution.x) / f32(options.resolution.y), 1.0);
    
    var mo = options.mouse.xy / vec2f(options.resolution);
    
    // Camera
    let an = -0.07 * options.time + 3.0 * mo.x;
    var ro = 4.5 * normalize(vec3<f32>(cos(an), 0.5, sin(an)));
    ro.y += 1.0;
    let ta = vec3<f32>(0.0, 0.5, 0.0);
    let cr = -0.4 * cos(0.02 * options.time);
    
    // Ray building
    let ww = normalize(ta - ro);
    let uu = normalize(cross(vec3<f32>(sin(cr), cos(cr), 0.0), ww));
    let vv = normalize(cross(ww, uu));
    let rd = normalize(p_ndc.x * uu + p_ndc.y * vv + 2.5 * ww);
    
    // Raymarching
    var sum = vec4<f32>(0.0);
    let bg = vec3<f32>(0.4, 0.5, 0.5) * 1.3;
    
    // Dithering
    var t = 0.05 * fract(10.5421 * dot(vec2<f32>(0.0149451, 0.038921), fragCoord.xy));
    
    for (var i: i32 = 0; i < 128; i++) {
        if (sum.a > 0.99) { break; }
        let pos = ro + t * rd;
        var col_sample = map(pos);
        
        col_sample.a *= 0.5;
        let fog = exp(-0.002 * t * t * t);
        col_sample = vec4<f32>(mix(bg, col_sample.rgb, fog) * col_sample.a, col_sample.a);
        
        sum = sum + col_sample * (1.0 - sum.a);
        t += 0.05;
    }
    
    var final_col = saturate(mix(bg, sum.xyz / (0.001 + sum.a), sum.a));
    
    // Post-processing
    final_col = final_col * final_col * (3.0 - 2.0 * final_col) * 1.4 - 0.4;
    final_col *= 0.25 + 0.75 * pow(16.0 * q_uv.x * q_uv.y * (1.0 - q_uv.x) * (1.0 - q_uv.y), 0.1);
    
    return vec4<f32>(final_col, 1.0);
}