// Procedural white noise 
fn hash2(p: vec2f) -> vec2f {
    let q = vec2f(dot(p, vec2f(127.1, 311.7)), dot(p, vec2f(269.5, 183.3)));
    return fract(sin(q) * 43758.5453);
}

fn voronoi(x: vec2f, time: f32) -> vec3f {
    let ip = floor(x);
    let fp = fract(x);

    // First pass: regular voronoi
    var mg: vec2f;
    var mr: vec2f;

    var md: f32 = 8.0;
    for (var j: i32 = -1; j <= 1; j++) {
        for (var i: i32 = -1; i <= 1; i++) {
            let g = vec2f(f32(i), f32(j));
            var o = hash2(ip + g);
            
            // Animation logic
            o = 0.5 + 0.5 * sin(time + 6.2831 * o);
            
            let r = g + o - fp;
            let d = dot(r, r);

            if (d < md) {
                md = d;
                mr = r;
                mg = g;
            }
        }
    }

    // Second pass: distance to borders
    md = 8.0;
    for (var j: i32 = -2; j <= 2; j++) {
        for (var i: i32 = -2; i <= 2; i++) {
            let g = mg + vec2f(f32(i), f32(j));
            var o = hash2(ip + g);
            
            o = 0.5 + 0.5 * sin(time + 6.2831 * o);
            
            let r = g + o - fp;

            if (dot(mr - r, mr - r) > 0.00001) {
                // Distance to line segment calculation
                md = min(md, dot(0.5 * (mr + r), normalize(r - mr)));
            }
        }
    }

    return vec3f(md, mr.x, mr.y);
}

fn main(p: vec2f, pos: vec2f, options: Options) -> vec4f {
    let c = voronoi(8.0 * p, options.time);

    // Isolines
    var col: vec3f = c.x * (0.5 + 0.5 * sin(64.0 * c.x)) * vec3f(1.0);
    
    // Borders
    col = mix(vec3f(1.0, 0.6, 0.0), col, smoothstep(0.04, 0.07, c.x));
    
    // Feature points
    let dd = length(c.yz);
    col = mix(vec3f(1.0, 0.6, 0.1), col, smoothstep(0.0, 0.12, dd));
    col += vec3f(1.0, 0.6, 0.1) * (1.0 - smoothstep(0.0, 0.04, dd));

    return vec4f(col, 1.0);
}