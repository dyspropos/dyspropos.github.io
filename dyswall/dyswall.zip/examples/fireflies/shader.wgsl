// 1. Define the "Object" state
struct RNG {
    state: u32,
};

// 2. Define the "Method"
// The 'ptr' argument allows the function to modify the struct's state
fn next_float(rng: ptr<function, RNG>) -> f32 {
    // A simple LCG (Linear Congruential Generator) step
    // state = (state * multiplier + increment)
    (*rng).state = (*rng).state * 1664525u + 1013904223u;
    
    // Map to [0.0, 1.0]
    return f32((*rng).state) * (1.0 / f32(0xffffffffu));
}

fn circle_sdf(p: vec2f, center: vec2f, radius: f32) -> f32 {
    return distance(p, center) - radius;
}

struct Fly {
    r: f32,
    omega: f32,
    omega2: f32,
    phase: f32,
};

fn random_fly(rng: ptr<function, RNG>) -> Fly {
    let r = next_float(rng) * 100.0 + 30.0;
    let omega = next_float(rng) * 5.0 + 0.0;
    let omega2 = next_float(rng) * 4.0 + 2.0;
    let phase = next_float(rng) * 6.28;
    return Fly(r, omega, omega2, phase);
}

fn random_color(rng: ptr<function, RNG>) -> vec3f {
    return vec3f(next_float(rng),next_float(rng),next_float(rng));
}

fn path(fly: Fly, time: f32) -> vec2f {
    let r0 = cos(time * fly.omega2 + fly.phase) + 2.0;
    let x = r0 * fly.r * cos(fly.omega*time);
    let y = fly.r * sin(fly.omega*time);

    return vec2f(x, y);
}

fn smin_quadratic( a: f32, b: f32, k_in: f32 ) -> f32
{
    let k = k_in * 16.0/3.0;
    let h = max( k-abs(a-b), 0.0 )/k;
    return min(a,b) - h*h*h*(4.0-h)*k*(1.0/16.0);
}

fn smin(a : f32, b : f32) -> f32 {
    return smin_quadratic(a, b, 0.1);
}

fn smin3f(a : vec3f, b : vec3f) -> vec3f {
    return vec3f(
        smin_quadratic(a.x, b.x, 0.1),
        smin_quadratic(a.y, b.y, 0.1),
        smin_quadratic(a.z, b.z, 0.1)
    );
}


fn main(uv: vec2f, pos: vec2f, options: Options) -> vec4f {
    var rng = RNG(127u);


    var df = 100.0;
    var fly_color = vec3f(0.0);
    for(var i = 0;i < 20; i += 1) {
        let radius = next_float(&rng) * 25.0 + 10.0;
        let d = circle_sdf(pos, options.mouse + path(random_fly(&rng), options.time), radius);
        let c = 2.0 * random_color(&rng);

        df = smin(df, d);
        if(d < 0) {
            let blend = abs(df / radius);
            let alpha = sqrt(blend);
            fly_color = fly_color * (1.0 - alpha) + alpha * c;
        }
    }

    var color = vec3f(0.0);
    if (df < 0.0) {
        color = fly_color;
    } 

    return vec4f(color, 1.0);
}